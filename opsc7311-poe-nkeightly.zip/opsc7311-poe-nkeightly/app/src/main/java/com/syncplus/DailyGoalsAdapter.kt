package com.syncplus

class DailyGoalsAdapter {
}